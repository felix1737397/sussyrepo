!function(o, e) {
var n = e.getElementById("loco-fs"), t = e.getElementById("loco-main");
n && t && o.loco.fs.init(n).setForm(t);
}(window, document, window.jQuery);