<?php
/**
 * Exception type for failed uploads
 */
class Loco_error_UploadException extends Loco_error_Exception {


}